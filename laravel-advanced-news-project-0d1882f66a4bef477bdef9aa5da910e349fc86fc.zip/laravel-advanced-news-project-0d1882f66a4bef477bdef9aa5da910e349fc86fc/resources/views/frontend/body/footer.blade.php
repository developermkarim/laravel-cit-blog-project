<footer class="footer-area">
<div class="container">
<div class="footer-menu">
<div class="menu-footer-menu-container"><ul id="menu-footer-menu" class="menu"><li id="menu-item-550" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-550"><a href=" ">ABOUT ALL</a></li>
<li id="menu-item-551" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-551"><a href=" ">COMPANY</a></li>
<li id="menu-item-552" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-552"><a href=" ">ABOUT US</a></li>
<li id="menu-item-553" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-553"><a href=" ">PHOTO GALLERY</a></li>
<li id="menu-item-554" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-554"><a href=" ">VIDOE GALLERY</a></li>
<li id="menu-item-555" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-555"><a href=" ">SUPPORT</a></li>
<li id="menu-item-556" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-556"><a href=" ">CONTACT</a></li>
<li id="menu-item-557" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-557"><a href=" ">REGISTER</a></li>
<li id="menu-item-558" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-558"><a href=" ">SEND NEWS </a></li>
</ul></div> </div>
<div class="footerColor">
<div class="row">
<div class="col-lg-5 col-md-5">
<h3 class="footer-title">
OFFICE : </h3>
<div class="footer-content">
<p style="text-align: left;">Ga-130/A Pragati Sarani, Middle Badda </p>
<p style="text-align: left;">EMAIL : support@easylearningbd.com</p>
<p style="text-align: left;">MOBILE : 4334343434</p> </div>
</div>
<div class="col-lg-7 col-md-7">
<div class="row">
<div class="col-lg-6 col-md-6">
<h3 class="footer-title">
DEMO TEXT </h3>
<div class="footer-content">
<p style="text-align: left;">DEMO TEXT : DEMO TEXT</p>
<p style="text-align: left;">DEMO TEXT : DEMO TEXT</p>
<p style="text-align: left;">DEMO TEXT : DEMO TEXT</p> </div>
</div>
<div class="col-lg-6 col-md-6">
<h3 class="footer-title">
DEMO TEXT </h3>
<div class="footer-content">
<p style="text-align: left;">DEMO TEXT : DEMO TEXT</p>
<p style="text-align: left;">DEMO TEXT :DEMO TEXT</p>
<p style="text-align: left;">DEMO TEXT : DEMO TEXT</p> </div>
</div>
</div>
</div>
</div>
<div class="copy_right_section">
<div class="row">
<div class="col-lg-6 col-md-6">
<div class="copy-right">
© All rights reserved © EasyNews </div>
</div>
<div class="col-lg-6 col-md-6">
<div class="design-developed">
Theme Developed BY <a href=" " target="_blank">easylearningbd.Com</a> </div>
</div>
</div>
</div>
</div>
<a href=" " class="scrollToTop" style=""><i class="las la-long-arrow-alt-up"></i></a>
</div>
</footer>